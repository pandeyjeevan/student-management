<?php
namespace App;
use Eloquent;
  class Teacher extends Eloquent
  {
  	public $table ='teachers';
  	public $timestamp = true;


  }