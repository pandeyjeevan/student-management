<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Teacher;
use Illuminate\Support\Facades\Input;

class TeachersController extends Controller
{
    public function InsertAllDataTeachers(){
    	$teacher = new Teacher;
    	

    	$teacher->teacher_name    =    Input::get('teacher_name');
    	$teacher->classteacher_of =    Input::get('classteacher_of');
    	$teacher->salary          =    Input::get('salary');
    	$teacher->save();

    	return view('displayteacherpage');
    }
}
