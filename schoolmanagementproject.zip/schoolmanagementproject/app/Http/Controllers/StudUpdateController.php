<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;


class StudUpdateController extends Controller {
public function index(){
$users = DB::select('select * from students');
return view('stud_edit_view',['users'=>$users]);
}
public function show($id) {
$users = DB::select('select * from students where student_id = ?',[$id]);
return view('stud_update',['users'=>$users]);
}
public function edit(Request $request,$id) {
$student_name = $request->input('student_name');
$stdent_class = $request->input('student_class');
$student_age = $request->input('student_age');
$class_teacher = $request->input('class_teacher');
//$data=array('first_name'=>$first_name,"last_name"=>$last_name,"city_name"=>$city_name,"email"=>$email);
//DB::table('student')->update($data);
// DB::table('student')->whereIn('id', $id)->update($request->all());
DB::update('update students set student_name = ?,student_class=?,student_age=?,class_teacher=? where student_id = ?',[$student_name,$student_class,$student_age,$class_teacher,$id]);
echo "Record updated successfully.
";
echo 'Click Here to go back.';
}
}