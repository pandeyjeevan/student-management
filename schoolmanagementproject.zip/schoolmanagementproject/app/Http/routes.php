<?php
use App\Teacher;
use App\Student;

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/insertinitialvaluesteachers',function(){
	$teacher = new Teacher();
	$teacher->teacher_id = 1;
	$teacher->teacher_name = 'Hari';
	$teacher->classteacher_of = 'II';
	$teacher->salary = '25000';
	$teacher->save();

	$teacher = new Teacher();
	$teacher->teacher_id = 2;
	$teacher->teacher_name = 'Shyam';
	$teacher->classteacher_of = 'III';
	$teacher->salary = '35000';
	$teacher->save();

	$teacher = new Teacher();
	$teacher->teacher_id = 3;
	$teacher->teacher_name = 'Sita';
	$teacher->classteacher_of = 'IV';
	$teacher->salary = '45000';
	$teacher->save();

});

Route::get('/insertinitialvaluesstudents',function(){
	$student = new Student();
	$student->student_id = 1;
	$student->student_name = 'Jeevan';
	$student->student_age =25;
	$student->student_class = 'II';
	$student->class_teacher = 'Shyam';
	$student->save();

	$student = new Student();
	$student->student_id = 2;
	$student->student_name = 'Raman';
	$student->student_age =20;
	$student->student_class = 'III';
	$student->class_teacher = 'Hari';
	$student->save();

    $student = new Student();
	$student->student_id = 3;
	$student->student_name = 'Ravi';
	$student->student_age =15;
	$student->student_class = 'IV';
	$student->class_teacher = 'Sita';
	$student->save();



});

Route::get('/displayteachers',function(){
	return view('displayteacherpage');
});

Route::get('/displaystudents',function(){
	return view('displaystudentpage');
});

Route::get('/insertteachers',function(){
	return view('InsertTeacherpage');
});

Route::post('InsertedDataTeachers','TeachersController@InsertAllDataTeachers');


Route::get('/insertstudents',function(){
	return view('InsertStudentpage');
});
Route::post('/InsertedDataTeachers','StudentsController@InsertAllDataStudents');




//delete data
Route::get('delete-records','StudDeleteController@index');
Route::get('delete/{id}','StudDeleteController@destroy');



//for update
Route::get('edit-records','StudUpdateController@index');
Route::get('edit/{id}','StudUpdateController@show');
Route::post('edit/{id}','StudUpdateController@edit'); 