<?php
namespace App;
use Eloquent;
  class Student extends Eloquent
  {
  	public $table ='students';
  	public $timestamp = true;


  }