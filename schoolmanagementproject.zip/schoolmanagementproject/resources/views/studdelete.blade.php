
<!DOCTPE html>
<html>
<head>
<title>View Student Records</title>
</head>
<body>
<table border = "1">
<tr>
<th>S NO.</th>
<th>Students Name</th>
<th>Student class </th>
<th>Student age</th>
<th>Class Teacher</th>
		
</tr>
@foreach ($users as $user)
<tr>
<td>{{ $user->student_id }}</td>
<td>{{ $user->student_name }}</td>
<td>{{ $user->student_class }}</td>
<td>{{ $user->student_age }}</td>
<td>{{ $user->class_teacher }}</td>
<td><a href = 'delete/{{ $user->student_id }}'>Delete</a></td>
</tr>
@endforeach
</table>
</body>
</html>