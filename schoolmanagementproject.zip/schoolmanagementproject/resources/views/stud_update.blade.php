<!DOCTYPE html>
<html>
<head>
<title>Student Management | Edit</title>
</head>
<body>
<form action = "/edit/<?php echo $users[0]->student_id; ?>" method = "post">
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<table>
<tr>
<td>Student Name</td>
<td>
<input type = 'text' name = 'student_name' 
value = '<?php echo$users[0]->student_name; ?>'/> </td>
</tr>
<tr>
<td>Student Class</td>
<td>
<input type = 'text' name = 'student_class' 
value = '<?php echo$users[0]->student_class; ?>'/>
</td>
</tr>
<tr>
<td>Student Age</td>
<td>
<input type = 'number' name = 'student_age' 
value = '<?php echo$users[0]->student_age; ?>'/>
</td>
</tr>
<tr>
<td>Class Teacher</td>
<td>
<input type = 'text' name = 'class_teacher' 
value = '<?php echo$users[0]->class_teacher; ?>'/>
</td>
</tr>
<tr>
<td colspan = '2'>
<input type = 'submit' value = "Update student" />
</td>
</tr>
</table>
</form>
</body>
</html>