<!DOCTYPE html>
<html>
<head>
	<title>Display Students</title>
	<h1>Dispaly Students From Database</h1>
</head>
<body>
	<table>
		<thead>
			<th>S NO.</th>
			<th>Students Name</th>
			<th>Student class </th>
			<th>Student age</th>
			<th>Class Teacher</th>
		
	</thead>
	<tbody>
		@for($i=1;$i <= DB::table('students')->count(); $i++)
		<tr>
			<?php $result = DB::table('students')->where('student_id','=',$i)->get() ?>
			<td>{{$result[0]->student_id}}</td>
			<td>{{$result[0]->student_name}}</td>
			<td>{{$result[0]->student_class}}</td>
			<td>{{$result[0]->student_age}}</td>
			<td>{{$result[0]->class_teacher}}</td>
		</tr>
		@endfor
	</tbody>
    </table>

</body>
</html>