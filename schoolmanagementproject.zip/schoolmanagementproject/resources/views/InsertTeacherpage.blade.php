


{{Form::open(array('action' =>'TeachersController@InsertAllDataTeachers'))}}

{{Form::label('teacher_name','Teacher Name')}}

{{Form::text('teacher_name','Enter Name Here',array('id' =>'teacher_name'))}}

<br>

{{Form::label('classteacher_of','Class Teacher Of')}}

{{Form::text('classteacher_of','Enter Class Here',array('id' =>'classteacher_of'))}}

<br>

{{Form::label('salary','Salary')}}

{{Form::number('salary',100,array('min' =>1, 'max' =>100000, 'id' =>'salary'))}}

<br>

{{Form::submit('Save')}}
{{Form::close()}}
