<!Doctype html>
<html>
<head>
<title>View Student Records</title>
</head>
<body>
<table border = "1">
<tr>
<th>S NO.</th>
<th>Students Name</th>
<th>Student class </th>
<th>Student age</th>
<th>Class Teacher</th>
</tr>
<?php foreach($users as $user): ?>
<tr>
<td><?php echo e($user->student_id); ?></td>
<td><?php echo e($user->student_name); ?></td>
<td><?php echo e($user->student_class); ?></td>
<td><?php echo e($user->student_age); ?></td>
<td><?php echo e($user->class_teacher); ?></td>
<td><a href = 'edit/<?php echo e($user->student_id); ?>'>Edit</a></td>
</tr>
<?php endforeach; ?>
</table>
</body>
</html>