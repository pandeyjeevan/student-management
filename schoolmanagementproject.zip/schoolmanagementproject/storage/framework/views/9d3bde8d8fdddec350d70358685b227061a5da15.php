


<?php echo e(Form::open(array('action' =>'StudentsController@InsertAllDataStudents'))); ?>


<?php echo e(Form::label('student_name','Student Name')); ?>


<?php echo e(Form::text('student_name','Enter Name Here',array('id' =>'student_name'))); ?>


<br>

<?php echo e(Form::label('student_class','Student Class')); ?>


<?php echo e(Form::text('student_class','Enter Class Here',array('id' =>'student_class'))); ?>


<br>

<?php echo e(Form::label('student_age','Student Age')); ?>


<?php echo e(Form::number('student_age',100,array('min' =>1, 'max' =>100, 'id' =>'student_age'))); ?>


<br>
 <?php echo e(Form::label('class_teacher','Class Teacher')); ?>

 <?php echo e(Form::text('class_teacher','Enter Class Teacher Here',array('id'=>'class_teacher'))); ?>


 <br>

<?php echo e(Form::submit('Save')); ?>

<?php echo e(Form::close()); ?>

