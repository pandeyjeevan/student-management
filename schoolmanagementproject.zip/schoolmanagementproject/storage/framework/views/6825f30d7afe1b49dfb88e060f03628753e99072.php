<!DOCTYPE html>
<html>
<head>
	<title>Display TeacherS</title>
	<h1>Display Teachers From Database</h1>
</head>
<body>
	<table>
		<thead>
			<th>S NO.</th>
			<th>Teachers Name</th>
			<th>Class Teacher Of</th>
			<th>Salary</th>
		
	</thead>
	<tbody>
		<?php for($i=1;$i <= DB::table('teachers')->count(); $i++): ?>
		
			<?php $result = DB::table('teachers')->where('teacher_id','=',$i)->get() ?>
		<tr>
			<td><?php echo e($result[0]->teacher_id); ?></td>
			<td><?php echo e($result[0]->teacher_name); ?></td>
			<td><?php echo e($result[0]->classteacher_of); ?></td>
			<td><?php echo e($result[0]->salary); ?></td>
		</tr>
		<?php endfor; ?>
	</tbody>
    </table>

</body>
</html>
